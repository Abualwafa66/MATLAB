function pr = nspr(m,g)

    pr = (1+2*g*(m.^2-1)/(g+1));
        
end
