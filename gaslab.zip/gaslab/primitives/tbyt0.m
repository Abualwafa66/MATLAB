function t = tbyt0(m,g)

    t =  1./ (1 + (g-1)*m.^2/2);
    
end
    
