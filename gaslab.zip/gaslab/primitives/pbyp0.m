function p = pbyp0(m,g)

    p = ( 1 + (g-1)*m.^2/2).^(g/(1-g));
    
end
    
